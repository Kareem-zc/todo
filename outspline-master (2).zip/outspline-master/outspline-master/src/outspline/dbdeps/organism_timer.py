# Outspline - A highly modular and extensible outliner.
# Copyright (C) 2011 Dario Giovannetti <dev@dariogiovannetti.net>
#
# This file is part of Outspline.
#
# Outspline is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Outspline is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Outspline.  If not, see <http://www.gnu.org/licenses/>.

import time

from outspline.extensions.organism_timer import queries


def add(cursor):
    cursor.execute(queries.timerproperties_create)
    cursor.execute(queries.timerproperties_insert, (int(time.time()), ))

def remove(cursor):
    cursor.execute(queries.timerproperties_drop)

def upgrade_0_to_1(cursor):
    # Placeholder/example
    # These queries must stay here because they must not be updated with the
    # normal queries
    pass
